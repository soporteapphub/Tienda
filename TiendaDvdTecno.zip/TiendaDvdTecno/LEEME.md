# Tienda DVD Tecno (Android)

## 1. Catálogo
1. Copia `catalogo-ejemplo.json`, llénalo con tus apps y súbelo a Dropbox como `catalogo.json`.
2. Copia su enlace compartido y pégalo en `app/src/main/java/com/dvdtecno/tienda/MainActivity.java`, en `CATALOG_URL`.
3. Para actualizar la tienda: reemplaza `catalogo.json` en Dropbox (mismo nombre y misma carpeta, así el enlace no cambia). Los clientes ven la lista nueva al abrir la app.
   Para cambiar una app por otra versión, sube el APK nuevo, cambia su `url` y `version` en el catálogo.
   Campo `dispositivo`: crea la ventana que quieras (Android, Fire TV, Smart TV...).

## 2. Compilar en GitHub
1. Crea un repositorio **privado** en github.com.
2. Sube TODO el contenido de esta carpeta (incluida la carpeta oculta `.github`) arrastrándola a «Add file > Upload files». Hazlo desde una computadora.
3. Ve a la pestaña **Actions**, abre «Compilar APK» y espera ~3 min.
4. Entra a esa ejecución, baja a **Artifacts** y descarga `Tienda-DVD-Tecno-APK`. Dentro está el `.apk`.

## 3. Instalar
Súbelo a Dropbox y pásalo por Downloader (Fire TV) o USB. La primera vez el equipo pedirá permitir instalar apps desconocidas.

## Notas
- La llave de firma `tienda.keystore` es la que permite actualizar la tienda sobre sí misma. No la pierdas y no hagas público el repositorio.
- Si cambias la app, sube `versionCode` en `app/build.gradle`.

## Actualizar la tienda misma
Compila la versión nueva con `versionCode` mayor en `app/build.gradle`, súbela a Dropbox y en `catalogo.json` pon ese mismo número en `tienda.versionCode` y su enlace en `tienda.url`. A los clientes les aparece el botón «Hay una versión nueva de la tienda».

## Logos
Agrega `"icono": "enlace-de-imagen-png-en-dropbox"` a cada app del catálogo. Si cambias el logo, súbelo con otro nombre de archivo (la tienda guarda copia de los ya vistos).
